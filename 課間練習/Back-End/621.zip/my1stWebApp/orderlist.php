<?php require_once('Connections/storeDB.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$colname_orderRecs = "-1";
if (isset($_SESSION['MM_Username'])) {
  $colname_orderRecs = $_SESSION['MM_Username'];
}
mysql_select_db($database_storeDB, $storeDB);
$query_orderRecs = sprintf("SELECT * FROM `order` WHERE `uid` = %s ORDER BY ptime ASC", GetSQLValueString($colname_orderRecs, "text"));
$orderRecs = mysql_query($query_orderRecs, $storeDB) or die(mysql_error());
$row_orderRecs = mysql_fetch_assoc($orderRecs);
$totalRows_orderRecs = mysql_num_rows($orderRecs);

$colname_UserRec = "-1";
if (isset($_SESSION['MM_Username'])) {
  $colname_UserRec = $_SESSION['MM_Username'];
}
mysql_select_db($database_storeDB, $storeDB);
$query_UserRec = sprintf("SELECT lastname, firstname FROM `user` WHERE username = %s", GetSQLValueString($colname_UserRec, "text"));
$UserRec = mysql_query($query_UserRec, $storeDB) or die(mysql_error());
$row_UserRec = mysql_fetch_assoc($UserRec);
$totalRows_UserRec = mysql_num_rows($UserRec);
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>訂單紀錄</title>
<style type="text/css">
body {
	
}
table {
	color: #00F;
	border: thick solid #6C6;
	left: 30px;
	top: 200px;
}
</style>
</head>
<center>
 <h2>
<?php echo $row_UserRec['firstname']; ?><?php echo $row_UserRec['lastname']; ?>
    ,你好!這是你的歷史定單紀錄
    <br>
    <a href="prodlist.php">回到網路商店</a>
</h2>
<body>
<table border="1" align="center">
  <tr>
    <th width="160" scope="col">訂單時間</th>
    <th width="172" scope="col">訂單內容</th>
    <th width="181" scope="col">總金額</th>
  </tr>
  <?php do { ?>
    <tr>
      <td><?php echo $row_orderRecs['ptime']; ?></td>
      <td><?php echo $row_orderRecs['oid']; ?></td>
      <td><?php echo $row_orderRecs['total']; ?></td>
    </tr>
    <?php } while ($row_orderRecs = mysql_fetch_assoc($orderRecs)); ?>
</table>

</body>
</html>
<?php
mysql_free_result($orderRecs);

mysql_free_result($UserRec);
?>
