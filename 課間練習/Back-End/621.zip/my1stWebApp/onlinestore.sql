-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- 主機: 127.0.0.1
-- 產生時間： 2017-06-17 17:40:18
-- 伺服器版本: 10.1.21-MariaDB
-- PHP 版本： 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- 資料庫： `onlinestore`
--

-- --------------------------------------------------------

--
-- 資料表結構 `order`
--

CREATE TABLE `order` (
  `oid` int(10) NOT NULL,
  `uid` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `ptime` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `nofitems` int(11) NOT NULL COMMENT 'number of items',
  `total` int(11) NOT NULL COMMENT '總金額'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- 資料表的匯出資料 `order`
--

INSERT INTO `order` (`oid`, `uid`, `ptime`, `nofitems`, `total`) VALUES
(1, 'zzz', '2017-06-07 02:00:00', 5, 100),
(2, 'zzz', '2017-06-07 02:00:00', 6, 100);

-- --------------------------------------------------------

--
-- 資料表結構 `orderitem`
--

CREATE TABLE `orderitem` (
  `oid` int(10) NOT NULL,
  `pid` int(10) NOT NULL,
  `nofitems` int(11) NOT NULL,
  `price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- 資料表結構 `product`
--

CREATE TABLE `product` (
  `pname` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `pno` int(10) UNSIGNED NOT NULL,
  `price` int(10) NOT NULL,
  `description` varchar(512) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- 資料表的匯出資料 `product`
--

INSERT INTO `product` (`pname`, `pno`, `price`, `description`) VALUES
('computer', 2, 15000, '???asdd'),
('abc', 5, 1, '11122');

-- --------------------------------------------------------

--
-- 資料表結構 `user`
--

CREATE TABLE `user` (
  `username` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `dob` date NOT NULL,
  `lastname` varchar(16) COLLATE utf8_unicode_ci NOT NULL,
  `firstname` varchar(16) COLLATE utf8_unicode_ci NOT NULL,
  `mobile` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `access` varchar(32) COLLATE utf8_unicode_ci NOT NULL COMMENT 'access level'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- 資料表的匯出資料 `user`
--

INSERT INTO `user` (`username`, `password`, `dob`, `lastname`, `firstname`, `mobile`, `access`) VALUES
('billhu@gmail.com', '1234', '2017-05-01', 'hu', 'bill', '0923-456-789', 'admin'),
('qqq', 'qqq', '1222-12-12', 'qqq', 'qqq', '0123456789', ''),
('qwe', '1', '1996-07-02', 'q', 'q', 'q', 'member'),
('rita', '111', '1996-11-16', '葉', '怡君', '0927379713', 'member'),
('xxx', 'xxx', '1235-12-12', 'xx', 'xx', '0123456789', 'member'),
('zzz', 'zzz', '1996-11-16', 'zz', 'zz', '0123456789', 'member');

--
-- 已匯出資料表的索引
--

--
-- 資料表索引 `order`
--
ALTER TABLE `order`
  ADD PRIMARY KEY (`oid`),
  ADD KEY `uid` (`uid`),
  ADD KEY `uid_2` (`uid`);

--
-- 資料表索引 `orderitem`
--
ALTER TABLE `orderitem`
  ADD PRIMARY KEY (`oid`),
  ADD KEY `oid` (`oid`,`pid`),
  ADD KEY `pid` (`pid`),
  ADD KEY `oid_2` (`oid`);

--
-- 資料表索引 `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`pno`);

--
-- 資料表索引 `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`username`);

--
-- 在匯出的資料表使用 AUTO_INCREMENT
--

--
-- 使用資料表 AUTO_INCREMENT `order`
--
ALTER TABLE `order`
  MODIFY `oid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- 使用資料表 AUTO_INCREMENT `product`
--
ALTER TABLE `product`
  MODIFY `pno` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- 已匯出資料表的限制(Constraint)
--

--
-- 資料表的 Constraints `order`
--
ALTER TABLE `order`
  ADD CONSTRAINT `o2uFK` FOREIGN KEY (`uid`) REFERENCES `user` (`username`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- 資料表的 Constraints `orderitem`
--
ALTER TABLE `orderitem`
  ADD CONSTRAINT `156` FOREIGN KEY (`oid`) REFERENCES `order` (`oid`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
