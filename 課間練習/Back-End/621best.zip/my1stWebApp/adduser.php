<?php require_once('Connections/storeDB.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "adduser")) {
  $insertSQL = sprintf("INSERT INTO user (username, password, dob, lastname, firstname, mobile, access) VALUES (%s, %s, %s, %s, %s, %s, %s)",
                       GetSQLValueString($_POST['username'], "text"),
                       GetSQLValueString($_POST['password'], "text"),
                       GetSQLValueString($_POST['dob'], "date"),
                       GetSQLValueString($_POST['lastname'], "text"),
                       GetSQLValueString($_POST['firstname'], "text"),
                       GetSQLValueString($_POST['mobile'], "text"),
                       GetSQLValueString($_POST['access'], "text"));

  mysql_select_db($database_storeDB, $storeDB);
  $Result1 = mysql_query($insertSQL, $storeDB) or die(mysql_error());

  $insertGoTo = "index.php";
  if (isset($_SERVER['QUERY_STRING'])) {
    $insertGoTo .= (strpos($insertGoTo, '?')) ? "&" : "?";
    $insertGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $insertGoTo));
}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>註冊</title>
<style type="text/css">
<!--
body {
	background-color: #FFC;
}
.form {
	background-color: #9F0;
	margin: 10px;
	padding: 10px;
	border: 5px double #F03;
	

}
.aaa {
	text-align: center;
	font-weight: bold;
}
-->
</style>
</head>

<body>
<div align="center">
<h1>創立一個新帳號吧!</h1>
<form action="<?php echo $editFormAction; ?>" name="adduser" method="POST" class="form">
<table border="1">
  <tr>
    <td width="165" class="aaa">帳號</td><td width="165"><input type="text" name="username"/></td>
  </tr>  
  <tr>
    <td class="aaa">密碼</td><td><input type="text" name="password"/></td>
  </tr>  
  <tr>
    <td class="aaa">生日</td><td><input name="dob" type="date"/></td>
    </tr>  
  <tr>  
    <td class="aaa">姓</td><td><input type="text" name="lastname"/></td>
    </tr>  
  <tr>  
    <td class="aaa">名</td><td><input type="text" name="firstname"/></td>
      </tr>  
  <tr>
    <td class="aaa">電話</td><td><input type="text" name="mobile"/></td>
  </tr>

</table>
<input type="hidden" name="access" value="member"/>
<input type="submit" name="adduser" id="adduser" value="new a user" />
<input type="hidden" name="MM_insert" value="adduser">
</form>
</div>
</body>
</html>