���} phpMyAdmin\libraries\Util.class.php
�� 1656�檺 return strftime($date, $timestamp);�令

if (extension_loaded('gettext'))

{    date_default_timezone_set('UTC');     

     return gmdate('Y-m-d H:i:s', $timestamp + 28800);

}